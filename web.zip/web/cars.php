<?php
$conn = mysqli_connect("localhost", "root", "", "city_bus_db");
if (!$conn) die("Connection failed: " . mysqli_connect_error());

// Simulate movement (every 5s)
if ($_GET['action'] ?? '' === 'simulate') {
    $result = mysqli_query($conn, "SELECT * FROM buses WHERE status = 'moving'");
    while ($bus = mysqli_fetch_assoc($result)) {
        $newLat = $bus['latitude'] + (rand(-5, 5) / 10000);
        $newLng = $bus['longitude'] + (rand(-5, 5) / 10000);
        mysqli_query($conn, "UPDATE buses SET latitude=$newLat, longitude=$newLng WHERE id={$bus['id']}");
        mysqli_query($conn, "INSERT INTO bus_trails (bus_id, latitude, longitude) VALUES ({$bus['id']}, $newLat, $newLng)");
    }
    exit;
}

// Return buses and trails
if ($_GET['action'] ?? '' === 'get_buses') {
    header('Content-Type: application/json');
    $data = [];
    $buses = mysqli_query($conn, "SELECT * FROM buses");
    while ($row = mysqli_fetch_assoc($buses)) {
        $trail = [];
        $res = mysqli_query($conn, "SELECT latitude, longitude FROM bus_trails WHERE bus_id={$row['id']} ORDER BY timestamp DESC LIMIT 20");
        while ($pt = mysqli_fetch_assoc($res)) {
            $trail[] = [$pt['latitude'], $pt['longitude']];
        }
        $row['trail'] = array_reverse($trail);
        $data[] = $row;
    }
    echo json_encode($data);
    exit;
}

// Start/Stop bus
if ($_POST['action'] ?? '' === 'update_status') {
    $id = intval($_POST['id']);
    $status = $_POST['status'] === 'moving' ? 'moving' : 'parked';
    $time = $status === 'moving' ? 'NOW()' : 'NULL';
    mysqli_query($conn, "UPDATE buses SET status='$status', start_time=$time WHERE id=$id");
    exit("OK");
}

// Add new bus
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['new_bus'])) {
    $name = mysqli_real_escape_string($conn, $_POST['name']);
    $lat = floatval($_POST['latitude']);
    $lng = floatval($_POST['longitude']);
    mysqli_query($conn, "INSERT INTO buses (name, status, latitude, longitude) VALUES ('$name', 'parked', $lat, $lng)");
    header("Location: map.php");
    exit;
}
?>
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8" />
  <title>City Bus Tracker</title>

  <!-- ✅ Leaflet CSS with integrity -->
  <link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css"
    integrity="sha256-p4NxAoJBhIIN+hmNHrzRCf9tD/miZyoHS5obTRR9BMY=" crossorigin="" />

  <style>
    body { margin: 0; font-family: Arial, sans-serif; }
    #map { height: 75vh; width: 100%; }
    #bus-form, #bus-list { padding: 10px; }
    table { width: 100%; border-collapse: collapse; margin-top: 10px; }
    th, td { padding: 6px; border: 1px solid #ccc; text-align: left; }
    button { padding: 4px 8px; margin: 2px; }
  </style>
</head>
<body>

<!-- ✅ Add New Bus Form -->
<div id="bus-form">
  <h3>Add New Bus</h3>
  <form method="post">
    <input type="hidden" name="new_bus" value="1">
    Name: <input type="text" name="name" required>
    Latitude: <input type="text" name="latitude" required>
    Longitude: <input type="text" name="longitude" required>
    <button type="submit">Add Bus</button>
  </form>
</div>

<!-- ✅ Map Container -->
<div id="map"></div>

<!-- ✅ Bus Status Table -->
<div id="bus-list">
  <h3>Bus Status</h3>
  <table id="statusTable">
    <thead><tr><th>ID</th><th>Name</th><th>Status</th><th>Start Time</th></tr></thead>
    <tbody></tbody>
  </table>
</div>

<!-- ✅ Leaflet JS with integrity (AFTER CSS) -->
<script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"
  integrity="sha256-20nQCchB9co0qIjJZRGuk2/Z9VM+kNiyxNV1lvTlZBo=" crossorigin=""></script>

<script>
  const map = L.map('map').setView([-1.9536, 30.0605], 13);
  L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png').addTo(map);

  let busMarkers = {}, busTrails = {};

  function updateStatus(id, status) {
    fetch('map.php', {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: `action=update_status&id=${id}&status=${status}`
    }).then(() => loadBuses());
  }

  function loadBuses() {
    fetch('map.php?action=get_buses')
      .then(res => res.json())
      .then(data => {
        document.querySelector('#statusTable tbody').innerHTML = '';
        data.forEach(bus => {
          const pos = [bus.latitude, bus.longitude];
          const popup = `
            <b>${bus.name}</b><br>
            Status: ${bus.status}<br>
            ${bus.start_time ? 'Started: ' + bus.start_time : ''}<br>
            <button onclick="updateStatus(${bus.id}, 'moving')">Start</button>
            <button onclick="updateStatus(${bus.id}, 'parked')">Stop</button>
          `;

          const icon = L.icon({
            iconUrl: bus.status === 'moving'
              ? 'https://cdn-icons-png.flaticon.com/512/61/61202.png'
              : 'https://cdn-icons-png.flaticon.com/512/2933/2933185.png',
            iconSize: [30, 30],
          });

          if (busMarkers[bus.id]) {
            busMarkers[bus.id].setLatLng(pos).setPopupContent(popup).setIcon(icon);
          } else {
            busMarkers[bus.id] = L.marker(pos, { icon }).addTo(map).bindPopup(popup);
          }

          // Draw trail
          if (busTrails[bus.id]) map.removeLayer(busTrails[bus.id]);
          if (bus.trail.length > 1) {
            busTrails[bus.id] = L.polyline(bus.trail, { color: 'blue' }).addTo(map);
          }

          // Update Table
          document.querySelector('#statusTable tbody').innerHTML += `
            <tr>
              <td>${bus.id}</td>
              <td>${bus.name}</td>
              <td>${bus.status}</td>
              <td>${bus.start_time ?? ''}</td>
            </tr>
          `;
        });
      });
  }

  function simulateMovement() {
    fetch('map.php?action=simulate');
  }

  // Auto-refresh
  setInterval(() => {
    simulateMovement();
    loadBuses();
  }, 5000);

  // Initial load
  loadBuses();
  simulateMovement();
</script>
</body>
</html>
