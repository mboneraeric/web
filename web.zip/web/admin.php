<?php
// Enable error reporting for debugging
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

session_start();

// Database connection info
$host = "localhost";
$user = "root";
$password = "";
$dbname = "web";

$error = "";

// Create connection
$conn = new mysqli($host, $user, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Handle form submission
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $username = trim($_POST['username']);
    $pass = $_POST['password'];

    if (strlen($username) < 8) {
        $error = "Username must be at least 8 characters.";
    } elseif (strlen($pass) < 8) {
        $error = "Password must be at least 8 characters.";
    } else {
        // Check if username exists
        $stmt = $conn->prepare("SELECT id FROM admins WHERE username = ?");
        $stmt->bind_param("s", $username);
        $stmt->execute();
        $stmt->store_result();

        if ($stmt->num_rows > 0) {
            $error = "Username already taken.";
        } else {
            $stmt->close();

            // Hash password and insert new admin
            $hash = password_hash($pass, PASSWORD_BCRYPT);
            $stmt = $conn->prepare("INSERT INTO admins (username, password) VALUES (?, ?)");
            $stmt->bind_param("ss", $username, $hash);

            if ($stmt->execute()) {
                // Redirect to login page
                header("Location: index.php");
                exit();
            } else {
                $error = "Registration failed: " . $stmt->error;
            }
            $stmt->close();
        }
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <title>Admin Registration</title>
  <style>
    body {
      font-family: Arial, sans-serif;
      background: #ecf0f1;
      display: flex;
      justify-content: center;
      align-items: center;
      height: 100vh;
      margin: 0;
    }
    .register-box {
      background: white;
      padding: 40px;
      border-radius: 10px;
      box-shadow: 0 0 15px rgba(0,0,0,0.1);
      width: 320px;
      text-align: center;
    }
    h2 {
      margin-bottom: 24px;
      color: #2c3e50;
    }
    label {
      display: block;
      margin-bottom: 6px;
      color: #34495e;
      font-weight: 600;
      text-align: left;
    }
    input[type="text"],
    input[type="password"] {
      width: 100%;
      padding: 12px;
      margin-bottom: 20px;
      border: 1px solid #bdc3c7;
      border-radius: 6px;
      font-size: 16px;
    }
    input[type="submit"] {
      width: 100%;
      padding: 12px;
      background-color: #27ae60;
      border: none;
      border-radius: 6px;
      color: white;
      font-weight: bold;
      cursor: pointer;
      font-size: 16px;
      transition: background-color 0.3s ease;
    }
    input[type="submit"]:hover {
      background-color: #1e8449;
    }
    .error {
      color: #e74c3c;
      margin-bottom: 20px;
    }
    a {
      color: #2980b9;
      text-decoration: none;
      font-weight: 600;
    }
    a:hover {
      text-decoration: underline;
    }
  </style>
</head>
<body>

  <div class="register-box">
    <h2>Admin Registration</h2>

    <?php if (!empty($error)): ?>
      <div class="error"><?php echo htmlspecialchars($error); ?></div>
    <?php endif; ?>

    <form method="POST" action="">
      <label for="username">Username</label>
      <input type="text" id="username" name="username" required autofocus />

      <label for="password">Password</label>
      <input type="password" id="password" name="password" required />

      <input type="submit" value="Register" />
    </form>

    <p style="margin-top: 15px; font-size: 14px;">
      Already have an account? <a href="index.php">Login here</a>.
    </p>
  </div>

</body>
</html>
