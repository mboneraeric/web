<?php
session_start();
if (!isset($_SESSION['client'])) {
    header("Location: client.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Client Dashboard</title>
  <style>
    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
    }

    body {
      display: flex;
      font-family: 'Segoe UI', sans-serif;
      background-color: #f4f4f4;
      height: 100vh;
    }

    .sidebar {
      width: 220px;
      background-color: #2c3e50;
      color: white;
      padding-top: 30px;
      position: fixed;
      height: 100%;
    }

    .sidebar h2 {
      text-align: center;
      margin-bottom: 30px;
    }

    .sidebar ul {
      list-style: none;
      padding-left: 0;
    }

    .sidebar ul li {
      padding: 15px 30px;
      border-bottom: 1px solid #34495e;
    }

    .sidebar ul li a {
      color: white;
      text-decoration: none;
      display: block;
    }

    .sidebar ul li a:hover {
      background-color: #1abc9c;
      border-radius: 4px;
    }

    .main-content {
      margin-left: 220px;
      padding: 40px;
      width: 100%;
    }

    .main-content h1 {
      margin-bottom: 20px;
      color: #2c3e50;
    }

    .info-box {
      background-color: white;
      padding: 20px;
      border-radius: 8px;
      box-shadow: 0 2px 8px rgba(0,0,0,0.1);
    }

    .logout-btn {
      display: block;
      text-align: center;
      margin-top: 30px;
      background-color: #e74c3c;
      padding: 10px;
      border-radius: 5px;
      color: white;
      text-decoration: none;
      width: 80%;
      margin-left: auto;
      margin-right: auto;
    }

    .logout-btn:hover {
      background-color: #c0392b;
    }
  </style>
</head>
<body>

  <div class="sidebar">
    <h2>🚌 Client Panel</h2>
    <ul>
      <li><a href="book_bus.php">Book Bus</a></li>
      <li><a href="client_logout.php" class="logout-btn">Logout</a></li>
    </ul>
  </div>

  <div class="main-content">
    <h1>Welcome, <?php echo htmlspecialchars($_SESSION['client']); ?>!</h1>
    <div class="info-box">
      <p>This is your client dashboard. From here you can book a bus or logout using the navigation on the left.</p>
    </div>
  </div>

</body>
</html>
