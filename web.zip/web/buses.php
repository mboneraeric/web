<?php
session_start();

// Dummy buses and prices
$buses = [
  ['id' => 1, 'bus_name' => 'Yutong', 'plot_number' => 'RAC001'],
  ['id' => 2, 'bus_name' => 'Yahoo', 'plot_number' => 'RAC002'],
  ['id' => 3, 'bus_name' => 'Kivubert', 'plot_number' => 'RAC003'],
  ['id' => 4, 'bus_name' => 'International', 'plot_number' => 'RAC004'],
];

// Directions and prices
$directions = [
  "Nyabugogo-Remera" => 1000,
  "Nyabugogo-Nyanza" => 2500,
  "Nyabugogo-Muhanga" => 1500,
  "Nyabugogo-Karongi" => 3500,
  "Nyabugogo-Nyamasheke" => 4500,
  "Nyabugogo-Rusizi" => 5000
];

// Initialize session data
$ticket = null;
$paid = false;
$error = "";
$notification = "";

// Simulated booked seats tracking (in session)
if (!isset($_SESSION['booked_seats'])) {
  $_SESSION['booked_seats'] = []; // Example: [bus_id => [seat_numbers]]
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $bus_id = $_POST['bus'] ?? '';
  $direction = $_POST['direction'] ?? '';
  $seat = $_POST['seat'] ?? '';
  $payment_method = $_POST['payment_method'] ?? '';
  $phone = $_POST['phone'] ?? '';

  if (!$bus_id || !$direction || !$seat || !$payment_method) {
    $error = "Please fill in all required fields.";
  } elseif ($payment_method === "Mobile Money" && empty($phone)) {
    $error = "Phone number is required for mobile money.";
  } elseif ($seat < 1 || $seat > 28) {
    $error = "Seat number must be between 1 and 28.";
  } elseif (in_array($seat, $_SESSION['booked_seats'][$bus_id] ?? [])) {
    $error = "Seat $seat is already taken.";
  } else {
    $_SESSION['booked_seats'][$bus_id][] = $seat;

    foreach ($buses as $bus) {
      if ($bus['id'] == $bus_id) {
        $ticket = [
          'bus_name' => $bus['bus_name'],
          'plot_number' => $bus['plot_number'],
          'direction' => $direction,
          'seat' => $seat,
          'price' => $directions[$direction],
          'payment_method' => $payment_method,
          'phone' => $payment_method === 'Mobile Money' ? $phone : 'N/A',
          'time' => date("Y-m-d H:i:s")
        ];
        $_SESSION['ticket'] = $ticket;
        $_SESSION['paid'] = true;

        $paid = true;
        $notification = $payment_method === "Mobile Money"
          ? "📲 Payment request sent to $phone. Please enter your PIN to confirm the transaction on your phone."
          : "💳 Card payment processed successfully.";
        break;
      }
    }
  }
} elseif (isset($_SESSION['ticket']) && $_SESSION['paid']) {
  $ticket = $_SESSION['ticket'];
  $paid = true;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <title>Bus Booking</title>
  <style>
    body {
      font-family: Arial, sans-serif;
      background: #f9f9f9;
      padding: 30px;
    }

    .container {
      max-width: 700px;
      margin: auto;
      background: white;
      padding: 30px;
      border-radius: 10px;
      box-shadow: 0 2px 10px rgba(0,0,0,0.1);
    }

    h2 {
      text-align: center;
      margin-bottom: 20px;
    }

    label {
      font-weight: bold;
      display: block;
      margin-top: 15px;
    }

    select, input[type="number"], input[type="text"], button {
      width: 100%;
      padding: 10px;
      margin-top: 5px;
      border-radius: 6px;
      border: 1px solid #ccc;
    }

    button {
      background: #1abc9c;
      color: white;
      font-weight: bold;
      margin-top: 20px;
      cursor: pointer;
    }

    button:hover {
      background: #16a085;
    }

    .error {
      background: #ffcccc;
      padding: 10px;
      border: 1px solid #e74c3c;
      margin-bottom: 15px;
      color: #c0392b;
      border-radius: 5px;
    }

    .notification {
      background: #f6e58d;
      padding: 10px;
      margin-bottom: 15px;
      border-radius: 5px;
      color: #2d3436;
    }

    .ticket {
      margin-top: 30px;
      border: 2px dashed #1abc9c;
      padding: 20px;
      border-radius: 10px;
      background: #ecf0f1;
    }

    .ticket p {
      margin: 8px 0;
    }

    .download-btn {
      display: inline-block;
      margin-top: 15px;
      background: #2980b9;
      color: white;
      padding: 10px 20px;
      text-decoration: none;
      border-radius: 6px;
    }

    .download-btn:hover {
      background: #2471a3;
    }

    #phoneField {
      display: none;
    }
  </style>
</head>
<body>

<div class="container">
  <h2>🚌 Bus Booking System</h2>

  <?php if ($error): ?>
    <div class="error"><?= $error ?></div>
  <?php endif; ?>

  <?php if ($notification): ?>
    <div class="notification"><?= $notification ?></div>
  <?php endif; ?>

  <?php if (!$ticket): ?>
    <form method="POST">
      <label>Select Direction</label>
      <select name="direction" required>
        <option value="">-- Choose Direction --</option>
        <?php foreach ($directions as $dir => $price): ?>
          <option value="<?= $dir ?>"><?= $dir ?> (<?= number_format($price) ?> RWF)</option>
        <?php endforeach; ?>
      </select>

      <label>Select Bus</label>
      <select name="bus" required>
        <option value="">-- Choose Bus --</option>
        <?php foreach ($buses as $bus): ?>
          <option value="<?= $bus['id'] ?>"><?= $bus['bus_name'] ?> (<?= $bus['plot_number'] ?>)</option>
        <?php endforeach; ?>
      </select>

      <label>Seat Number (1-28)</label>
      <input type="number" name="seat" min="1" max="28" required />

      <label>Payment Method</label>
      <select name="payment_method" id="payment_method" onchange="togglePhone()" required>
        <option value="">-- Choose Payment --</option>
        <option value="Card">Card</option>
        <option value="Mobile Money">Mobile Money</option>
      </select>

      <div id="phoneField">
        <label>Phone Number (MoMo)</label>
        <input type="text" name="phone" placeholder="07xxxxxxxx" pattern="07[0-9]{8}" />
      </div>

      <button type="submit">Book and Pay</button>
    </form>
  <?php elseif ($paid): ?>
    <div class="ticket" id="ticket">
      <h3>🎫 Your Ticket</h3>
      <p><strong>Bus:</strong> <?= htmlspecialchars($ticket['bus_name']) ?> (<?= htmlspecialchars($ticket['plot_number']) ?>)</p>
      <p><strong>Direction:</strong> <?= htmlspecialchars($ticket['direction']) ?></p>
      <p><strong>Seat:</strong> <?= htmlspecialchars($ticket['seat']) ?></p>
      <p><strong>Amount:</strong> <?= number_format($ticket['price']) ?> RWF</p>
      <p><strong>Payment:</strong> <?= $ticket['payment_method'] ?> (<?= $ticket['phone'] ?>)</p>
      <p><strong>Time:</strong> <?= htmlspecialchars($ticket['time']) ?></p>
    </div>
    <a class="download-btn" href="#" onclick="printTicket()">Download Ticket</a>
  <?php endif; ?>
</div>

<script>
  function togglePhone() {
    const method = document.getElementById('payment_method').value;
    document.getElementById('phoneField').style.display = method === 'Mobile Money' ? 'block' : 'none';
  }

  function printTicket() {
    const content = document.getElementById('ticket').innerHTML;
    const win = window.open('', '', 'height=600,width=800');
    win.document.write('<html><head><title>Your Ticket</title></head><body>');
    win.document.write(content);
    win.document.write('</body></html>');
    win.document.close();
    win.print();
  }
</script>

</body>
</html>
