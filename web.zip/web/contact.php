<?php
session_start();
$isLoggedIn = isset($_SESSION['client']);
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <title>Client Contact</title>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" />

  <style>
    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
    }

    body {
      display: flex;
      font-family: 'Segoe UI', sans-serif;
      background: linear-gradient(to right, #6dd5fa, #ffffff);
      height: 100vh;
      overflow: hidden;
    }

    .sidebar {
      width: 220px;
      background-color: #2c3e50;
      color: white;
      padding-top: 30px;
      position: fixed;
      height: 100%;
      box-shadow: 2px 0 6px rgba(0,0,0,0.1);
    }

    .sidebar h2 {
      text-align: center;
      margin-bottom: 30px;
    }

    .sidebar ul {
      list-style: none;
      padding-left: 0;
    }

    .sidebar ul li {
      padding: 15px 30px;
      border-bottom: 1px solid #34495e;
    }

    .sidebar ul li a {
      color: white;
      text-decoration: none;
      display: block;
      transition: all 0.3s ease;
    }

    .sidebar ul li a:hover {
      background-color: #1abc9c;
      border-radius: 4px;
    }

    .logout-btn {
      display: block;
      text-align: center;
      margin-top: 30px;
      background-color: #e74c3c;
      padding: 10px;
      border-radius: 5px;
      color: white;
      text-decoration: none;
      width: 80%;
      margin: 30px auto 0;
    }

    .logout-btn:hover {
      background-color: #c0392b;
    }

    .main-content {
      margin-left: 220px;
      padding: 40px;
      width: 100%;
    }

    .main-content h1 {
      margin-bottom: 20px;
      color: #2c3e50;
      font-size: 32px;
      font-weight: bold;
    }

    .contact-info {
      background: rgba(255, 255, 255, 0.8);
      backdrop-filter: blur(8px);
      padding: 30px;
      border-radius: 12px;
      box-shadow: 0 4px 15px rgba(0,0,0,0.1);
      transition: all 0.3s ease;
    }

    .contact-item {
      display: flex;
      align-items: center;
      margin-bottom: 20px;
      font-size: 18px;
      color: #333;
    }

    .contact-item i {
      font-size: 22px;
      color: #1abc9c;
      width: 40px;
      text-align: center;
      transition: transform 0.3s ease;
    }

    .contact-item a, .contact-item span {
      text-decoration: none;
      color: #2c3e50;
      transition: color 0.3s ease;
    }

    .contact-item a:hover {
      color: #1abc9c;
      text-decoration: underline;
    }

    .contact-item:hover i {
      transform: scale(1.2);
    }

    @media (max-width: 768px) {
      .sidebar {
        width: 180px;
      }
      .main-content {
        margin-left: 180px;
      }
    }
  </style>
</head>
<body>

    <?php if ($isLoggedIn): ?>
      <a class="logout-btn" href="client_logout.php">Logout</a>
    <?php endif; ?>
  </div>

  <div class="main-content">
    <h1>Contact Us</h1>
    <div class="contact-info">
      <div class="contact-item">
        <i class="fas fa-envelope"></i>
        <a href="mailto:geniuseric1@gmail.com">geniuseric1@gmail.com</a>
      </div>
      <div class="contact-item">
        <i class="fab fa-facebook"></i>
        <a href="https://facebook.com" target="_blank">Mbonera Eric</a>
      </div>
      <div class="contact-item">
        <i class="fab fa-instagram"></i>
        <a href="https://instagram.com" target="_blank">@mbonera_officiel</a>
      </div>
      <div class="contact-item">
        <i class="fas fa-phone"></i>
        <span>+250 792097254 / +250 726599487</span>
      </div>
    </div>
  </div>

</body>
</html>
