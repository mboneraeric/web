<?php
session_start();
$isLoggedIn = isset($_SESSION['client']);
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <title>Client Home</title>
  <style>
    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
    }

    body {
      display: flex;
      font-family: 'Segoe UI', sans-serif;
      background-color: #f4f4f4;
      height: 100vh;
    }

    .sidebar {
      width: 220px;
      background-color: #2c3e50;
      color: white;
      padding-top: 30px;
      position: fixed;
      height: 100%;
    }

    .sidebar h2 {
      text-align: center;
      margin-bottom: 30px;
    }

    .sidebar ul {
      list-style: none;
      padding-left: 0;
    }

    .sidebar ul li {
      padding: 15px 30px;
      border-bottom: 1px solid #34495e;
    }

    .sidebar ul li a {
      color: white;
      text-decoration: none;
      display: block;
    }

    .sidebar ul li a:hover {
      background-color: #1abc9c;
      border-radius: 4px;
    }

    .main-content {
      margin-left: 220px;
      padding: 40px;
      width: 100%;
    }

    .logout {
      display: block;
      text-align: center;
      margin-top: 30px;
      background-color: #e74c3c;
      padding: 10px;
      border-radius: 5px;
      color: white;
      text-decoration: none;
      width: 80%;
      margin-left: auto;
      margin-right: auto;
    }

    .logout:hover {
      background-color: #c0392b;
    }

    .btn {
      display: inline-block;
      margin-top: 20px;
      padding: 12px 20px;
      background-color: #1abc9c;
      color: white;
      text-decoration: none;
      border-radius: 5px;
      font-weight: bold;
      transition: background-color 0.3s ease;
    }

    .btn:hover {
      background-color: #16a085;
    }
  </style>
</head>
<body>

  <div class="sidebar">
    <h2>🚗 Car Portal</h2>
    <ul>
      <li><a href="dashboard.php">Dashboard</a></li>
      <li><a href="contact.php">Contact</a></li>
      <li><a href="client_dashboard.php">Client</a></li>
    </ul>

    <?php if ($isLoggedIn): ?>
      <a class="logout" href="client_logout.php">Logout</a>
    <?php endif; ?>
  </div>

  <div class="main-content">
    <h1>Welcome to Client Portal</h1>
    <p>This is the main home page. Use the navigation on the left to explore your dashboard and client info.</p>

    <a class="btn" href="client_dashboard.php">Go to Dashboard</a>
  </div>

</body>
</html>
